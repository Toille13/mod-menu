# Roblox Mod Menu

This is an educational demonstration of a Roblox mod menu interface. It simulates various gameplay modifications such as ESP (wallhacks), aimbot, teleportation, flying, and enhanced jumping capabilities.

## ⚠️ Educational Purpose Only

This project is a **conceptual demonstration** of how game modification menus work. This tool:
- Does NOT actually modify any games
- Cannot be used to cheat in Roblox
- Is for educational purposes only

## Features

The mod menu includes visual demonstrations of:

- **Movement Mods**
  - Enhanced Jump (adjustable height)
  - Fly Mode (adjustable speed)

- **Combat Mods**
  - Aimbot with customizable settings
  - Teleportation to players

- **Visual Mods**
  - ESP (Player Boxes) with customizable colors and information display
  - Wall Hack with adjustable transparency

## Keyboard Shortcuts

- `F` - Toggle flight
- `T` - Teleport to target
- `L` - Lock/unlock target for aimbot
- `V` - Toggle wallhack
- `Insert` - Toggle menu visibility

## Setup and Usage

1. Clone this repository
2. Open `index.html` in a web browser
3. Experiment with the mod menu controls in the demonstration interface

## Important Reminder

Using actual cheats in online games:
- Violates Terms of Service
- Can result in permanent account bans
- Ruins the gaming experience for others
- May be illegal in some jurisdictions

## Project Structure

- `index.html` - Main interface
- `styles.css` - Styling for the mod menu
- `script.js` - Core functionality and simulation
- `disclaimer.js` - Disclaimer handler
- `modules/` - Individual mod feature modules
  - `jumpModule.js` - Jump enhancement features
  - `flyModule.js` - Flying capabilities
  - `aimbotModule.js` - Aimbot targeting features
  - `espModule.js` - ESP (player box) visualization
  - `teleportModule.js` - Teleportation features
  - `wallhackModule.js` - Wall transparency features